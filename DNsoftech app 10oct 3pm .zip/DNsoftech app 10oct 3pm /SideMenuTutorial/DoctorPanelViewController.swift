//
//  VastuViewController.swift
//  Mahrshi app
//
//  Created by adithya on 9/6/18.
//  Copyright © 2018 Parth Changela. All rights reserved.
//

import UIKit

class DoctorPanelViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet var menuButton: UIBarButtonItem!
    let doctorEdu = ["About Web Design","About HTML Development","About Print Media Design","About Responsive Website","About PHP Development","About Android Development"]
    let doctorsList = ["Web Design","HTML Development","Print Media Design","Responsive Website","PHP Development","Android Development"]
    let doctorImages = ["index-2_img01.jpg","index-2_img02.jpg","index-2_img03.jpg","index-2_img04.jpg","index-2_img05.jpg","index-2_img06.jpg"]
    
    let doctordata = ["Business-To-Business website design considerations might differ greatly from a consumer targeted website such as a retail or entertainment website. We create such a webdesign to target audience for your specific market.\n\nWeb design encompasses many different skills and disciplines in the production and maintenance of websites. The different areas of web design include web graphic design; interface design; authoring, including standardised code and proprietary software; user experience design; and search engine optimization. Often many individuals will work in teams covering different aspects of the design process, although some designers will cover them all.[1] The term web design is normally used to describe the design process relating to the front-end (client side) design of a website including writing mark up. Web design partially overlaps web engineering in the broader scope of web development. Web designers are expected to have an awareness of usability and if their role involves creating mark up then they are also expected to be up to date with web accessibility guidelines.","If you are building a business on the web, it is a very cost effective way to promote your business. And here we are for you.\n\nAn HTML editor is a program for editing HTML, the markup of a webpage. Although the HTML markup in a web page can be controlled with any text editor, specialized HTML editors can offer convenience and added functionality. For example, many HTML editors handle not only HTML, but also related technologies such as CSS, XML and JavaScript or ECMAScript. In some cases they also manage communication with remote web servers via FTP and WebDAV, and version control systems such as Subversion or Git. Many word processing, graphic design and page layout programs that are not dedicated to web design, such as Microsoft Word or Quark XPress, also have the ability to function as HTML editors.","Print media allows you to choose your own space for advertisement, thus, you can manage your budget and expenses while planning for the advertisement.\n\nPrint design, a subset of graphic design, is a form of visual communication used to convey information to an audience through intentional aesthetic design printed on a tangible surface, designed to be printed on paper, as opposed to presented on a digital platform. A design can be considered print design if its final form was created through an imprint made by the impact of a stamp, seal, or dye on the surface of the paper.","Responsive web design means higher rankings in Google search. It not need separate website designs for tablets, iPhones, desktops, and laptops.We provide you the responsive websites you've always dreamed of.\n\nResponsive web design (RWD) is an approach to web design that makes web pages render well on a variety of devices and window or screen sizes. Recent work also considers the viewer proximity as part of the viewing context as an extension for RWD.Content, design and performance are necessary across all devices to ensure usability and satisfaction.\n\nA site designed with RWD adapts the layout to the viewing environment by using fluid, proportion-based grids,flexible images,and CSS3 media queries, an extension of the media rule, in the following ways.\n\nThe fluid grid concept calls for page element sizing to be in relative units like percentages, rather than absolute units like pixels or points.\n\nFlexible images are also sized in relative units, so as to prevent them from displaying outside their containing element.\n\nMedia queries allow the page to use different CSS style rules based on characteristics of the device the site is being displayed on, most commonly the width of the browser.","In today's competitive market, it is important to create website, which functions fast & easy to multi tasking. When you consider the potential market you can reach with a websiteWe provide you the same here.\n\nPHP: Hypertext Preprocessor (or simply PHP) is a server-side scripting language designed for Web development, but also used as a general-purpose programming language. It was originally created by Rasmus Lerdorf in 1994,the PHP reference implementation is now produced by The PHP Group.PHP originally stood for Personal Home Page,but it now stands for the recursive initialism PHP: Hypertext Preprocessor.","We guarantee great android mobile application.The devoted android mobile application veterans. Only incredible android mobile applications we provide you.We have skilled android mobile application artisans\n\nAndroid software development is the process by which new applications are created for devices running the Android operating system. Google states that,Android apps can be written using Kotlin, Java, and C++ languages using the Android software development kit (SDK), while using other languages is also possible. All non-JVM languages, such as Go (JavaScript, C, C++ or assembly), need the help of JVM language code, that may be supplied by tools, likely with restricted API support. Some languages/programming tools allow cross-platform app support, i.e. for both Android and iOS. Third party tools, development environments and language support have also continued to evolve and expand since the initial SDK was released in 2008. In addition, with major business entities like Walmart, Amazon, Bank of America etc. eyeing to engage and sell through mobiles, mobile application development is witnessing a transformation."]
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return doctorsList.count
    }
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! DoctorPanelTableViewCell
        cell.doctorList.text = doctorsList[indexPath.row]
       // cell.imageviewss.image = UIImage(named: doctorImages[indexPath.row])

        cell.borderLayer.layer.cornerRadius = 15
        cell.borderLayer.layer.masksToBounds = false

        cell.borderLayer.layer.shadowOpacity = 0.78
        cell.borderLayer.layer.shadowOffset = CGSize(width: 0, height: 2)
        cell.borderLayer.layer.shadowRadius = 7
        cell.borderLayer.layer.shadowColor = UIColor.black.cgColor
        cell.borderLayer.layer.masksToBounds = false
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vmi = self.storyboard?.instantiateViewController(withIdentifier: "Doctor")as! DoctorPanelDetailViewController
        vmi.str =  doctorEdu[indexPath.row]
        vmi.str2 =  doctorImages[indexPath.row]
        vmi.str3 =  doctordata[indexPath.row]
        self.navigationController?.pushViewController(vmi, animated: true)

    }
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
