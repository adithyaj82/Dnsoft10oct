//
//  OurServViewController.swift
//  Dnsoftech app
//
//  Created by adithya on 10/10/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class OurServViewController: UIViewController,UITableViewDataSource,UITableViewDelegate  {
    
    @IBOutlet var menuButton: UIBarButtonItem!
    let doctorsList = ["Web Design & Development","Mobile Applications","SEO Service","Server","Email Marketing"]
    let doctorsDetlimage = ["web-design.jpg","mobile_app.jpg","top-seo.png","server.jpg","Email-Marketing.png"]
    let doctorstitle = ["Static Web Design","Mobile App","SEO","Domain Registration","Email Marketing"]
    
    let doctorsTextview = ["We offer you Static Website Designing services in Ahmedabad,Gujarat,India.Web design encompasses many different skills and disciplines in the production and maintainence of websites.A static website has web pages with fixed content in each page.\n\nStatic Website Designing involves small as well as huge websites but with simple designs and without complex programming. WebShree provides static website designing services which is appealing and creative. These static websites allows businesses to explain their company's goals and objectives. We help you in planning, design, and development of your personal or corporate websites. The main purpose of our static website designing services it to provide you with an online presence. This would help you to showcase your products and earn business. These website designs did not require databases, ecommerce systems or extensive custom coding.\n\nDynamic website designing required advanced and more complicated coding than static websites designing. The layout of the pages and the content of the web pages are created separately. All the content is stored in a database. Words, numbers, and images are stored as unique elements in the database and put together to be displayed on a page only if asked. This allows you to provide individual information to the user and let them personalize the content according to their preferences.\n\nDynamic website Designing is suitable for that kind of business houses were details about their products and services are keep changing frequently, With the help of control panel the administrator of the website can change the desired products and information on their website.\n\nClassic Web Designs is specialized dynamic website designing company in India and our designs are visually attractive, user-friendly and deliver the message simply and effectively. As dynamic websites are data base oriented websites which keeps your data safe and secure. It also provides services such as online-shops, paying by credit card and so on. Dynamic web development also provides option to access one or more people who can edit the website with different permissions.\n\nResponsive web design (RWD) is an approach to web design that makes web pages render well on a variety of devices and window or screen sizes. Recent work also considers the viewer proximity as part of the viewing context as an extension for RWD.","We offer you Mobile Appllication Designing servicesin ahmedabad,Gujarat,India.Mobile apps are created mainly for small wireless devices.like phones,tablets etc.\n\nAndroid App Development\n\nAs the mobile ecosystem continues to expand, businesses are creating mobile apps to capture the connected consumer. Ideally, mobile apps should be developed for both the major app platforms, iOS and Android. However, there is often debate around which platform is best to build on first.It is a common strategy, when building mobile apps, to build on one platform first, test it, get feedback, make iterations and then build on the other. So which app platform do you develop on first? In order to shine some light on the iOS vs Android debate, here are some pros and cons of each platform.\n\nIphone Application Development\n\niOS presents a more stable and exclusive platform for developers that is easier to use. It is a closed platform where Apple design all of their own hardware and software, allowing them to implement strict guidelines. As a result, the platform is quick and responsive, apps are designed well, and there is generally less piracy.","We offer you SEO Services in Ahmedabad,Gujarat,India.SEO redirects here search engine optimization.SEO is the process of affecting the visibility of a website or a web page in a web search engine's unpaid results.More freuently a site appers in the search result list,the more visitors it will receive from the search engine's users. We wing your business to the top of the Google Searches and that’s what makes us the best SEO Company in Ahmedabad (India). We are an absolute fusion of innovation, strategy, and technology, leveraging our experience and expertise to some of the best businesses in the world. With our suite of fully integrated digital marketing services, we provide sustainable and massive business growth. We maintain the intrinsic value of your brand digitally and make sure that your customers can experience it at every touchpoint. It is safe to say that we are result-oriented, as we wholeheartedly love and practice SEO.","At inventive networks we provide generic and country specific TLDs domain name Registration.We are established to serve you and give you an affordable and simplle way to get your creativity and ideas through hosting your website online.Registering a domain name is very crucial now a day for any individual or even an firm too.Domains builds a reputaion of your website to target your audience,it not only helps you over come your competitors but also helps you to create a online web presence.you can search a unique domain name based on keyboard for your website.\n\nDomain registration information is maintained by the domain name registries, which contract with domain registrars to provide registration services to the public. An end user selects a registrar to provide the registration service, and that registrar becomes the designated registrar for the domain chosen by the user.\n\nOnly the designated registrar may modify or delete information about domain names in a central registry database. It is not unusual for an end user to switch registrars, invoking a domain transfer process between the registrars involved, that is governed by specific domain name transfer policies.\n\nWhen a registrar registers a com domain name for an end-user, it must pay a maximum annual fee of US$7.34 to VeriSign, the registry operator for com, and a US$0.18 annual administration fee to ICANN. Most domain registrars price their services and products to address both the annual fees and the administration fees that must be paid to ICANN. Barriers to entry into the bulk registrar industry are high for new companies without an existing customer base.","Personalized Digital interactions with Niche Audiences through EmailMarketing\n\nOver the years,email has emerged as one of the most effective forms of digital marketing.Traditionally,only leveraged as a mass mailing tool,the evolving face of the new age customer opens a host of new avenues through email to initiate an engaging two-way communication.\n\nPersonalization via Email Marketing:\n\nOur experts recognize that the modern day customer demands high level of personalization through interactive dialogues not only in social media but also via email.By understanding the pulse of this shit in user expectation,we have been able to helps brands up their digital interactivity game by making email marketing a significant part of their online strategy.\n\nOur experts work closely with brands across a host of industries to pursue a comprehensive analysis of the existing marketing situation as  well as setting realistic,achievable and profitable email marketing goals.By channelling the right email marketing strategy at the right time to the customers,this effort is able to play an integral role in the overall corporate objectives for your brand."]

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return doctorsList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! OurServTableViewCell
        
        cell.doctorList.text = doctorsList[indexPath.row]
        // cell.imageviewss.image = UIImage(named: doctorImages[indexPath.row])
        
        cell.borderLayer.layer.cornerRadius = 15
        cell.borderLayer.layer.masksToBounds = false
        
        cell.borderLayer.layer.shadowOpacity = 0.78
        cell.borderLayer.layer.shadowOffset = CGSize(width: 0, height: 2)
        cell.borderLayer.layer.shadowRadius = 7
        cell.borderLayer.layer.shadowColor = UIColor.black.cgColor
        cell.borderLayer.layer.masksToBounds = false
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vmim = self.storyboard?.instantiateViewController(withIdentifier: "OurServicesDetail")as! OurServicesDetailViewController
        vmim.str4 = doctorsDetlimage[indexPath.row]
        vmim.str5 = doctorstitle[indexPath.row]
        vmim.str6 = doctorsTextview[indexPath.row]
        self.navigationController?.pushViewController(vmim, animated: true)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
